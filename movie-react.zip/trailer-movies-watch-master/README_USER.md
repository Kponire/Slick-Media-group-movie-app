# Trailers Movies Watch

## Просмотр трейлеров фильмов на реакте

![img-portfolio](https://user-images.githubusercontent.com/56477695/178304967-a35c9e9e-f09d-4cd9-bb51-a88ead2774d3.jpg)

### Features

- Watch trailers your loves movies/serials
- Search movies/serials
- Most rated, popular and upcoming movies

### Возможности

- Смотрите трейлеры ваших любимых фильмов/сериалов
- Поиск фильмов/сериалов
- Самые рейтинговые, популярные и предстоящие фильмы

## Authors/Авторы 

- [@witcherwow240](https://www.github.com/VladimirSaenko)
- [@AlexanderKhapchenko](https://github.com/AlexanderKhapchenko)
